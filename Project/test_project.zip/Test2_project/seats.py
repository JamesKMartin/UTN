class Seat():

    def __init__(self, seat_number, is_reserved):
        self.seat_number = seat_number
        self.is_reserved = is_reserved
