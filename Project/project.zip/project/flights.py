class Flight():
	def __init__(self, flightID, company, From, to, duration, date, time, prize_per_ticket):
		self.flightID = flightID
		self.company = company
		self.From = From
		self.to = to
		self.duration = duration
		self.date = date
		self.time = time
		self.prize_per_ticket = prize_per_ticket
